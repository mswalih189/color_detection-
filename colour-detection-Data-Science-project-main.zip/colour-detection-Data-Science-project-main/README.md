# colour-detection-Data-Science-project
The Python-based Color Detection Project identifies and displays the name and RGB values of any pixel in an image. Using OpenCV, NumPy, and a Pandas-stored color CSV, it calculates the closest match via RGB distance. Users upload an image, click a pixel, and view the identified color dynamically, aiding in color analysis and design.
